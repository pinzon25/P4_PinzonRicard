package com.example.p4_pinzonricard;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.RotateDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

import java.io.IOException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView mTitol;
    ImageView mHomer;
    ImageView mEngranatgeVermell;
    ImageView mEngranatgeVerd;
    ImageView mEngranatgeBlau;
    ImageView mUll;
    ImageView mDonut;
    MediaPlayer audio;

    boolean titol;
    boolean homer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTitol = (ImageView) findViewById(R.id.imageTitol);
        mTitol.setOnClickListener(this);

        mHomer = (ImageView)findViewById(R.id.imageHomer);
        mHomer.setOnClickListener(this);

        mEngranatgeVermell = (ImageView) findViewById(R.id.imageEngranatgeVermell);
        mEngranatgeVerd = (ImageView) findViewById(R.id.imageEngranatgeVerd);
        mEngranatgeBlau = (ImageView) findViewById(R.id.imageEngranatgeBlau);
        mUll = (ImageView) findViewById(R.id.imageUll);
        mDonut = (ImageView) findViewById(R.id.imageDonut);

        mEngranatgeVermell.setVisibility(View.INVISIBLE);
        mEngranatgeVerd.setVisibility(View.INVISIBLE);
        mEngranatgeBlau.setVisibility(View.INVISIBLE);
        mUll.setVisibility(View.INVISIBLE);
        mDonut.setVisibility(View.INVISIBLE);

        audio = MediaPlayer.create(getApplicationContext(),R.raw.the_simpsons); //Se declara primero.
        mDonut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        if(homer == false){
            audio.start();
            homer = true;
        }else{
            audio.stop();
            homer = false;
            audio = MediaPlayer.create(getApplicationContext(),R.raw.the_simpsons);
             }
            }
        });

        titol=false;
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()){
            case R.id.imageTitol:

                AnimationDrawable animacioTitol = (AnimationDrawable) mTitol.getDrawable();
                Animation animEngranatgeVermell = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.engranatge_vermell);
                Animation animEngranatgeBlau = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.engranatge_blau);
                Animation animEngranatgeVerd = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.engranatge_verd);
                Animation animRotacioUll = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.animacio_ull);
                Animation animDonut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.animacio_donut);

                if(!titol) {
                    animacioTitol.start();
                    mEngranatgeVermell.setVisibility(View.VISIBLE);
                    mEngranatgeVerd.setVisibility(View.VISIBLE);
                    mEngranatgeBlau.setVisibility(View.VISIBLE);
                    mUll.setVisibility(View.VISIBLE);
                    mDonut.setVisibility(View.VISIBLE);
                    mEngranatgeVermell.startAnimation(animEngranatgeVermell);
                    mEngranatgeBlau.startAnimation(animEngranatgeBlau);
                    mEngranatgeVerd.startAnimation(animEngranatgeVerd);
                    mUll.startAnimation(animRotacioUll);
                    mDonut.startAnimation(animDonut);

                    titol = true;//Aqui ja tenim la animacio funcionant. Com el boolea esta declarat fals, la negacio del if es converteix en true, per tant, si es true, entra.


                }else {
                    animacioTitol.stop();
                    titol=false;
                    mEngranatgeVermell.clearAnimation();
                    mEngranatgeBlau.clearAnimation();
                    mEngranatgeVerd.clearAnimation();
                    mUll.clearAnimation();
                    mDonut.clearAnimation();
                    mEngranatgeVermell.setVisibility(View.INVISIBLE);
                    mEngranatgeVerd.setVisibility(View.INVISIBLE);
                    mEngranatgeBlau.setVisibility(View.INVISIBLE);
                    mUll.setVisibility(View.INVISIBLE);
                    mDonut.setVisibility(View.INVISIBLE);
                    homer=false;
                    audio.stop();
                    homer=false;
                    audio = MediaPlayer.create(getApplicationContext(),R.raw.the_simpsons);
                }

                break;
    /*
            case R.id.imageDonut:

                if(audio.isPlaying()){
                    audio.pause();
                    // audio.stop();
                } else{
                    try {
                        audio.prepare();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    audio.seekTo(0);
                    audio.start();
                }

                break;*/
        }

    }
}
